# Quick Start Guide - Offline Browser

## Building the APK

### Option 1: Using Android Studio (Recommended)

1. **Download and Install Android Studio**
   - Download from: https://developer.android.com/studio
   - Install with default settings

2. **Open the Project**
   - Launch Android Studio
   - Click "Open" and select the `OfflineBrowser` folder
   - Wait for Gradle sync to complete

3. **Build Debug APK**
   - Click `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
   - Or press `Ctrl+F9` (Windows/Linux) or `Cmd+F9` (Mac)

4. **Find the APK**
   - APK location: `app/build/outputs/apk/debug/app-debug.apk`
   - Click "locate" in the notification to open folder

5. **Install on Device**
   - Enable "Developer Options" on your Android device
   - Enable "USB Debugging"
   - Connect device via USB
   - Click "Run" button (▶) in Android Studio
   - Or manually install: `adb install app-debug.apk`

### Option 2: Using Command Line

1. **Install Prerequisites**
   ```bash
   # Install JDK 17
   sudo apt-get install openjdk-17-jdk  # Ubuntu/Debian
   brew install openjdk@17               # macOS
   
   # Install Android SDK
   # Download from: https://developer.android.com/studio#command-tools
   ```

2. **Set Environment Variables**
   ```bash
   export ANDROID_SDK_ROOT=/path/to/android-sdk
   export PATH=$PATH:$ANDROID_SDK_ROOT/tools:$ANDROID_SDK_ROOT/platform-tools
   ```

3. **Build APK**
   ```bash
   cd OfflineBrowser
   ./gradlew assembleDebug
   ```

4. **Find APK**
   - Location: `app/build/outputs/apk/debug/app-debug.apk`

### Option 3: Using Build Script

```bash
cd OfflineBrowser
chmod +x build-apk.sh
./build-apk.sh
```

## Installing Extensions

### Chrome Extensions

1. Download extension CRX file from Chrome Web Store
2. Rename `.crx` to `.zip` and extract
3. Copy extracted folder to:
   ```
   /Android/data/com.offlinebrowser/files/extensions/[extension-id]/
   ```
4. Restart browser
5. Go to Menu → Extensions → Enable the extension

### Firefox Extensions

1. Download extension XPI file
2. Rename `.xpi` to `.zip` and extract
3. Copy to extensions folder as above
4. Restart browser

## Saving Pages Offline

1. Navigate to any web page
2. Tap the **Save** button (floating button with download icon)
3. Page will be downloaded and compressed
4. Access saved pages: Menu → Offline Pages

## Troubleshooting

### Build Errors

**Gradle sync failed**
- Check internet connection
- Update Android Studio to latest version
- Try: `File` → `Invalidate Caches / Restart`

**Out of memory**
- Increase heap size in `gradle.properties`:
  ```
  org.gradle.jvmargs=-Xmx4096m
  ```

### Runtime Issues

**Extensions not loading**
- Check extension folder path is correct
- Verify manifest.json is valid
- Restart browser after installing

**Pages not saving offline**
- Check storage permission is granted
- Ensure sufficient free space
- Try saving smaller pages first

**App crashes**
- Clear app data: Settings → Apps → Offline Browser → Clear Data
- Reinstall the app
- Check logcat for errors: `adb logcat`

## Need Help?

- Read full documentation: `README.md`
- Check project structure and code comments
- Open an issue on the project repository