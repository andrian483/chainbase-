# Offline Browser

A feature-rich Android browser with extension support and offline page saving capabilities, similar to Opera Mini.

## Features

### Core Browser Features
- **Fast WebView-based browsing** - Smooth and responsive web experience
- **Tab support** - Manage multiple tabs
- **Navigation controls** - Back, forward, home, and refresh
- **Address bar with search** - Search or enter URLs directly
- **Progress indicator** - Visual loading progress
- **Pull-to-refresh** - Easy page refresh gesture
- **Download manager** - Handle file downloads

### Extension Support
- **Chrome Extension compatible** - Supports Manifest V2/V3 extensions
- **Firefox Extension support** - WebExtension API compatibility
- **Content scripts** - Inject scripts into web pages
- **Background scripts** - Run extension logic
- **Storage API** - Extension data persistence
- **Tabs API** - Tab management for extensions
- **WebRequest API** - Intercept and modify requests

### Offline Page Saving (Opera Mini-like)
- **Save pages for offline** - Download complete web pages
- **Compressed storage** - GZIP compression for efficient storage
- **Resource downloading** - Saves images, CSS, and scripts
- **Offline viewer** - Built-in viewer for saved pages
- **Page management** - Organize and delete saved pages
- **Search offline pages** - Find saved content quickly
- **Export/Import** - Backup and restore saved pages

### Privacy & Security
- **JavaScript toggle** - Enable/disable JavaScript
- **Cookie management** - Control cookie settings
- **Ad blocking** - Built-in ad blocker support
- **Data saver mode** - Compress pages to save data
- **Clear browsing data** - Remove history, cookies, cache

### Customization
- **Search engine selection** - Google, Bing, DuckDuckGo, Yahoo, Ecosia
- **Text size adjustment** - Small, Normal, Large, Extra Large
- **Dark/Light theme** - Automatic theme support

## Project Structure

```
OfflineBrowser/
├── app/
│   ├── src/main/
│   │   ├── java/com/offlinebrowser/
│   │   │   ├── ui/
│   │   │   │   ├── MainActivity.kt           # Main browser activity
│   │   │   │   ├── OfflinePagesActivity.kt   # Manage saved pages
│   │   │   │   ├── OfflineViewerActivity.kt  # View saved pages
│   │   │   │   ├── ExtensionManagerActivity.kt # Manage extensions
│   │   │   │   └── SettingsActivity.kt       # App settings
│   │   │   ├── extension/
│   │   │   │   └── ExtensionManager.kt       # Extension system
│   │   │   ├── offline/
│   │   │   │   └── OfflinePageManager.kt     # Offline saving logic
│   │   │   └── OfflineBrowserApp.kt          # Application class
│   │   ├── res/
│   │   │   ├── layout/                       # UI layouts
│   │   │   ├── drawable/                     # Icons and graphics
│   │   │   ├── values/                       # Strings, colors, themes
│   │   │   ├── menu/                         # Menu definitions
│   │   │   └── xml/                          # Configuration files
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── gradle/
    └── wrapper/
        └── gradle-wrapper.properties
```

## Building the APK

### Prerequisites
- Android Studio Arctic Fox or later
- JDK 17 or later
- Android SDK 34

### Build Steps

1. **Open in Android Studio**
   ```bash
   # Open the OfflineBrowser folder in Android Studio
   ```

2. **Sync Gradle**
   - Click "Sync Now" in the notification bar
   - Or run: `./gradlew sync`

3. **Build Debug APK**
   ```bash
   ./gradlew assembleDebug
   ```
   Output: `app/build/outputs/apk/debug/app-debug.apk`

4. **Build Release APK**
   ```bash
   ./gradlew assembleRelease
   ```
   Output: `app/build/outputs/apk/release/app-release-unsigned.apk`

5. **Sign Release APK**
   ```bash
   # Generate keystore (first time only)
   keytool -genkey -v -keystore offlinebrowser.keystore -alias offlinebrowser -keyalg RSA -keysize 2048 -validity 10000
   
   # Sign APK
   jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore offlinebrowser.keystore app-release-unsigned.apk offlinebrowser
   
   # Align APK
   zipalign -v 4 app-release-unsigned.apk OfflineBrowser-v1.0.0.apk
   ```

## Installing Extensions

### Chrome Extensions
1. Download the extension CRX file or extract the extension folder
2. Place the extracted extension folder in:
   ```
   /Android/data/com.offlinebrowser/files/extensions/
   ```
3. Restart the browser
4. Enable the extension in Extension Manager

### Firefox Extensions
1. Download the extension XPI file (rename to .zip and extract)
2. Place the extracted folder in the extensions directory
3. Restart the browser

### Supported Extension APIs
- `browser.runtime` / `chrome.runtime`
- `browser.storage.local` / `chrome.storage.local`
- `browser.tabs` / `chrome.tabs`
- `browser.webNavigation` / `chrome.webNavigation`
- `browser.webRequest` / `chrome.webRequest`
- `browser.downloads` / `chrome.downloads`
- `browser.contextMenus` / `chrome.contextMenus`
- `browser.notifications` / `chrome.notifications`

## Saving Pages Offline

### How to Save
1. Navigate to any web page
2. Tap the **Save** button (floating action button)
3. Page will be downloaded and compressed

### Viewing Offline Pages
1. Open the menu (⋮) → "Offline Pages"
2. Tap any saved page to view
3. Pages load instantly without internet

### Managing Saved Pages
- **Search**: Use the search bar to find pages
- **Delete**: Swipe or tap delete icon
- **Clear All**: Menu → Clear All
- **Storage info**: See total size in subtitle

## Technical Details

### Offline Storage Format
- **HTML**: Modified HTML with local resource paths
- **Compression**: GZIP for efficient storage
- **Resources**: Downloaded to local folder
- **Metadata**: JSON index for fast access

### Extension Injection
- Content scripts injected after page load
- Background scripts run in isolated context
- APIs implemented via JavaScript bridge

### Permissions Required
- `INTERNET` - Web browsing
- `ACCESS_NETWORK_STATE` - Network detection
- `WRITE_EXTERNAL_STORAGE` - Downloads (API < 29)
- `DOWNLOAD_WITHOUT_NOTIFICATION` - Silent downloads
- `FOREGROUND_SERVICE` - Background tasks

## Known Limitations

### Extensions
- Limited WebExtension API support
- No popup UI for extensions
- Background scripts run in-page context
- Some APIs are stubbed

### Offline Saving
- Dynamic content may not be captured
- Large pages may fail to save
- Some resources may be blocked by CORS
- JavaScript-heavy sites may not work offline

## Future Enhancements
- [ ] Full tab management with UI
- [ ] Bookmark management
- [ ] History management
- [ ] Password manager integration
- [ ] Reader mode
- [ ] Night mode
- [ ] Gesture navigation
- [ ] Voice search
- [ ] QR code scanner
- [ ] Sync across devices

## License

MIT License - Free to use and modify.

## Contributing

Contributions are welcome! Please submit pull requests or open issues for bugs and feature requests.

## Support

For support, please open an issue on the project repository.