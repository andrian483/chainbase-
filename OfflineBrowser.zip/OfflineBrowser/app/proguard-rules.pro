# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.

# Keep WebView methods
-keepclassmembers class * extends android.webkit.WebView {
    public *;
}

# Keep JavaScript interface
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep Kotlin
-keep class kotlin.** { *; }
-keep class kotlin.Metadata { *; }
-dontwarn kotlin.**

# Keep AndroidX
-keep class androidx.** { *; }
-keep interface androidx.** { *; }

# Keep WebViewClient
-keep class * extends android.webkit.WebViewClient { *; }

# Keep WebChromeClient
-keep class * extends android.webkit.WebChromeClient { *; }

# Keep model classes
-keep class com.offlinebrowser.offline.OfflinePageManager\$* { *; }
-keep class com.offlinebrowser.extension.ExtensionManager\$* { *; }

# Keep activities
-keep class com.offlinebrowser.ui.* { *; }