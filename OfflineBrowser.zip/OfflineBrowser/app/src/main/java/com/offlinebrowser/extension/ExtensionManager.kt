package com.offlinebrowser.extension

import android.content.Context
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class ExtensionManager(private val context: Context) {
    
    private val extensionsDir: File by lazy {
        File(context.filesDir, "extensions").apply {
            if (!exists()) mkdirs()
        }
    }
    
    private val installedExtensions = mutableListOf<Extension>()
    
    data class Extension(
        val id: String,
        val name: String,
        val version: String,
        val description: String,
        val author: String,
        val manifest: JSONObject,
        val path: String,
        var isEnabled: Boolean = true,
        val type: ExtensionType = ExtensionType.CHROME
    )
    
    enum class ExtensionType {
        CHROME, FIREFOX
    }
    
    init {
        loadInstalledExtensions()
    }
    
    private fun loadInstalledExtensions() {
        installedExtensions.clear()
        
        extensionsDir.listFiles()?.forEach { extDir ->
            if (extDir.isDirectory) {
                val manifestFile = File(extDir, "manifest.json")
                if (manifestFile.exists()) {
                    try {
                        val manifest = JSONObject(manifestFile.readText())
                        val ext = parseExtension(manifest, extDir)
                        if (ext != null) {
                            installedExtensions.add(ext)
                        }
                    } catch (e: Exception) {
                        // Invalid manifest
                    }
                }
            }
        }
    }
    
    private fun parseExtension(manifest: JSONObject, extDir: File): Extension? {
        return try {
            val manifestVersion = manifest.optInt("manifest_version", 2)
            val id = manifest.optString("id", extDir.name)
            
            Extension(
                id = id,
                name = manifest.getString("name"),
                version = manifest.getString("version"),
                description = manifest.optString("description", ""),
                author = manifest.optString("author", "Unknown"),
                manifest = manifest,
                path = extDir.absolutePath,
                isEnabled = true,
                type = if (manifest.has("browser_specific_settings")) 
                    ExtensionType.FIREFOX else ExtensionType.CHROME
            )
        } catch (e: Exception) {
            null
        }
    }
    
    fun getInstalledExtensions(): List<Extension> {
        return installedExtensions.toList()
    }
    
    fun getEnabledExtensions(): List<Extension> {
        return installedExtensions.filter { it.isEnabled }
    }
    
    fun toggleExtension(extId: String, enabled: Boolean) {
        val ext = installedExtensions.find { it.id == extId }
        ext?.isEnabled = enabled
        saveExtensionState()
    }
    
    private fun saveExtensionState() {
        val stateFile = File(extensionsDir, "state.json")
        val json = JSONObject()
        installedExtensions.forEach { ext ->
            json.put(ext.id, ext.isEnabled)
        }
        stateFile.writeText(json.toString())
    }
    
    fun injectExtensions(webView: WebView) {
        // Inject extension APIs
        injectWebExtensionAPI(webView)
    }
    
    fun injectContentScripts(webView: WebView, url: String) {
        getEnabledExtensions().forEach { ext ->
            injectContentScriptsForExtension(webView, ext, url)
        }
    }
    
    private fun injectWebExtensionAPI(webView: WebView) {
        val apiScript = """
            (function() {
                if (window.browser || window.chrome) return;
                
                window.browser = {
                    runtime: {
                        onMessage: {
                            addListener: function(callback) {
                                window.__extensionListeners = window.__extensionListeners || [];
                                window.__extensionListeners.push(callback);
                            }
                        },
                        sendMessage: function(message) {
                            return new Promise(function(resolve) {
                                OfflineBrowser.postMessage(JSON.stringify({
                                    type: 'runtime.sendMessage',
                                    data: message
                                }));
                                resolve();
                            });
                        },
                        getURL: function(path) {
                            return 'file://__extensions__/' + path;
                        }
                    },
                    storage: {
                        local: {
                            get: function(keys) {
                                return new Promise(function(resolve) {
                                    var result = {};
                                    try {
                                        var data = localStorage.getItem('__ext_storage__');
                                        if (data) {
                                            var stored = JSON.parse(data);
                                            if (Array.isArray(keys)) {
                                                keys.forEach(function(k) {
                                                    if (stored[k] !== undefined) result[k] = stored[k];
                                                });
                                            } else if (keys) {
                                                if (stored[keys] !== undefined) result[keys] = stored[keys];
                                            } else {
                                                result = stored;
                                            }
                                        }
                                    } catch(e) {}
                                    resolve(result);
                                });
                            },
                            set: function(items) {
                                return new Promise(function(resolve) {
                                    try {
                                        var data = localStorage.getItem('__ext_storage__');
                                        var stored = data ? JSON.parse(data) : {};
                                        Object.assign(stored, items);
                                        localStorage.setItem('__ext_storage__', JSON.stringify(stored));
                                    } catch(e) {}
                                    resolve();
                                });
                            },
                            remove: function(keys) {
                                return new Promise(function(resolve) {
                                    try {
                                        var data = localStorage.getItem('__ext_storage__');
                                        var stored = data ? JSON.parse(data) : {};
                                        if (Array.isArray(keys)) {
                                            keys.forEach(function(k) { delete stored[k]; });
                                        } else {
                                            delete stored[keys];
                                        }
                                        localStorage.setItem('__ext_storage__', JSON.stringify(stored));
                                    } catch(e) {}
                                    resolve();
                                });
                            }
                        }
                    },
                    tabs: {
                        query: function(queryInfo) {
                            return new Promise(function(resolve) {
                                resolve([{
                                    id: 1,
                                    url: location.href,
                                    title: document.title,
                                    active: true
                                }]);
                            });
                        },
                        sendMessage: function(tabId, message) {
                            return new Promise(function(resolve) {
                                if (window.__extensionListeners) {
                                    window.__extensionListeners.forEach(function(listener) {
                                        listener(message, {tab: {id: 1}}, function(response) {});
                                    });
                                }
                                resolve();
                            });
                        }
                    },
                    webNavigation: {
                        onCompleted: {
                            addListener: function(callback) {
                                if (document.readyState === 'complete') {
                                    callback({tabId: 1, url: location.href});
                                } else {
                                    window.addEventListener('load', function() {
                                        callback({tabId: 1, url: location.href});
                                    });
                                }
                            }
                        }
                    },
                    webRequest: {
                        onBeforeRequest: {
                            addListener: function(callback, filter, extraInfo) {
                                // Intercept fetch/XHR
                                var originalFetch = window.fetch;
                                window.fetch = function() {
                                    var url = arguments[0];
                                    var details = {
                                        url: url,
                                        method: 'GET',
                                        type: 'xmlhttprequest'
                                    };
                                    var result = callback(details);
                                    if (result && result.cancel) {
                                        return Promise.reject('Request blocked by extension');
                                    }
                                    return originalFetch.apply(window, arguments);
                                };
                            }
                        }
                    },
                    downloads: {
                        download: function(options) {
                            return new Promise(function(resolve, reject) {
                                var link = document.createElement('a');
                                link.href = options.url;
                                link.download = options.filename || '';
                                document.body.appendChild(link);
                                link.click();
                                document.body.removeChild(link);
                                resolve(1);
                            });
                        }
                    },
                    contextMenus: {
                        create: function(createProperties, callback) {
                            // Store for native menu integration
                            window.__contextMenuItems = window.__contextMenuItems || [];
                            window.__contextMenuItems.push(createProperties);
                            if (callback) callback();
                        },
                        onClicked: {
                            addListener: function(callback) {
                                window.__contextMenuCallback = callback;
                            }
                        }
                    },
                    notifications: {
                        create: function(notificationId, options) {
                            return new Promise(function(resolve) {
                                if ('Notification' in window && Notification.permission === 'granted') {
                                    new Notification(options.title, {
                                        body: options.message,
                                        icon: options.icon
                                    });
                                }
                                resolve(notificationId || 'notification_' + Date.now());
                            });
                        }
                    }
                };
                
                // Alias chrome to browser
                window.chrome = window.browser;
                
                // Dispatch event for extensions
                window.dispatchEvent(new CustomEvent('extension-api-ready'));
            })();
        """.trimIndent()
        
        webView.evaluateJavascript(apiScript, null)
    }
    
    private fun injectContentScriptsForExtension(webView: WebView, ext: Extension, url: String) {
        val manifest = ext.manifest
        
        // Get content scripts from manifest
        val contentScripts = when {
            manifest.has("content_scripts") -> manifest.getJSONArray("content_scripts")
            manifest.has("contentScripts") -> manifest.getJSONObject("contentScripts")
                .optJSONArray("matches") ?: JSONArray()
            else -> null
        } ?: return
        
        for (i in 0 until contentScripts.length()) {
            try {
                val script = contentScripts.getJSONObject(i)
                
                // Check if URL matches
                val matches = script.optJSONArray("matches")
                if (matches != null && !urlMatches(url, matches)) {
                    continue
                }
                
                // Inject JS files
                val jsFiles = script.optJSONArray("js")
                if (jsFiles != null) {
                    for (j in 0 until jsFiles.length()) {
                        val jsFile = File(ext.path, jsFiles.getString(j))
                        if (jsFile.exists()) {
                            val jsCode = jsFile.readText()
                            webView.evaluateJavascript(wrapContentScript(jsCode, ext.id), null)
                        }
                    }
                }
                
                // Inject CSS files
                val cssFiles = script.optJSONArray("css")
                if (cssFiles != null) {
                    val cssBuilder = StringBuilder()
                    for (j in 0 until cssFiles.length()) {
                        val cssFile = File(ext.path, cssFiles.getString(j))
                        if (cssFile.exists()) {
                            cssBuilder.append(cssFile.readText())
                        }
                    }
                    if (cssBuilder.isNotEmpty()) {
                        injectCSS(webView, cssBuilder.toString())
                    }
                }
                
            } catch (e: Exception) {
                // Skip invalid content scripts
            }
        }
    }
    
    private fun wrapContentScript(code: String, extensionId: String): String {
        return """
            (function() {
                var __extensionId = '$extensionId';
                try {
                    $code
                } catch(e) {
                    console.error('Extension error:', e);
                }
            })();
        """.trimIndent()
    }
    
    private fun injectCSS(webView: WebView, css: String) {
        val escapedCss = css.replace("\"", "\\\"").replace("\n", "\\n")
        val script = """
            (function() {
                var style = document.createElement('style');
                style.textContent = "$escapedCss";
                document.head.appendChild(style);
            })();
        """.trimIndent()
        webView.evaluateJavascript(script, null)
    }
    
    private fun urlMatches(url: String, patterns: JSONArray): Boolean {
        for (i in 0 until patterns.length()) {
            val pattern = patterns.getString(i)
            val regex = pattern
                .replace(".", "\\.")
                .replace("*", ".*")
                .replace("?", "\\?")
            if (Regex(regex).matches(url)) {
                return true
            }
        }
        return false
    }
    
    fun interceptResource(url: String) {
        // Allow extensions to intercept and modify resources
        // This is called from WebViewClient
    }
    
    fun installExtension(extensionPath: String): Boolean {
        return try {
            val sourceDir = File(extensionPath)
            if (!sourceDir.exists() || !sourceDir.isDirectory) {
                return false
            }
            
            val manifestFile = File(sourceDir, "manifest.json")
            if (!manifestFile.exists()) {
                return false
            }
            
            // Parse manifest to get extension ID
            val manifest = JSONObject(manifestFile.readText())
            val id = manifest.optString("id", sourceDir.name)
            
            // Copy to extensions directory
            val targetDir = File(extensionsDir, id)
            if (targetDir.exists()) {
                targetDir.deleteRecursively()
            }
            
            sourceDir.copyRecursively(targetDir)
            
            // Reload extensions
            loadInstalledExtensions()
            
            true
        } catch (e: Exception) {
            false
        }
    }
    
    fun uninstallExtension(extId: String): Boolean {
        val extDir = File(extensionsDir, extId)
        return if (extDir.exists()) {
            extDir.deleteRecursively()
            loadInstalledExtensions()
            true
        } else {
            false
        }
    }
}