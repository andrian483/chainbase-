package com.offlinebrowser.offline

import android.content.Context
import android.graphics.Bitmap
import android.webkit.WebView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.net.URL
import java.security.MessageDigest
import java.util.*
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

class OfflinePageManager(private val context: Context) {
    
    private val offlineDir: File by lazy {
        File(context.filesDir, "offline_pages").apply {
            if (!exists()) mkdirs()
        }
    }
    
    private val indexFile: File by lazy {
        File(offlineDir, "index.json")
    }
    
    data class OfflinePage(
        val id: String,
        val url: String,
        val title: String,
        val timestamp: Long,
        val filePath: String,
        val size: Long,
        val favicon: String? = null,
        val isCompressed: Boolean = true
    )
    
    suspend fun savePage(webView: WebView, url: String, title: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val pageId = generatePageId(url)
            val timestamp = System.currentTimeMillis()
            
            // Create page directory
            val pageDir = File(offlineDir, pageId)
            if (!pageDir.exists()) pageDir.mkdirs()
            
            // Get page HTML content
            val htmlContent = getPageContent(webView)
            
            // Extract and download resources
            val resources = extractAndSaveResources(htmlContent, pageDir, url)
            
            // Modify HTML to use local resources
            val modifiedHtml = modifyHtmlForOffline(htmlContent, resources)
            
            // Save main HTML file (compressed)
            val htmlFile = File(pageDir, "index.html.gz")
            saveCompressed(modifiedHtml, htmlFile)
            
            // Save metadata
            val metadata = JSONObject().apply {
                put("id", pageId)
                put("url", url)
                put("title", title)
                put("timestamp", timestamp)
                put("resources", JSONArray(resources.values))
                put("originalSize", modifiedHtml.length)
            }
            
            val metaFile = File(pageDir, "meta.json")
            metaFile.writeText(metadata.toString())
            
            // Update index
            updateIndex(OfflinePage(
                id = pageId,
                url = url,
                title = title,
                timestamp = timestamp,
                filePath = pageDir.absolutePath,
                size = htmlFile.length(),
                isCompressed = true
            ))
            
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
    
    private suspend fun getPageContent(webView: WebView): String = withContext(Dispatchers.Main) {
        val js = """
            (function() {
                var html = document.documentElement.outerHTML;
                var base = document.baseURI;
                return JSON.stringify({html: html, base: base});
            })();
        """.trimIndent()
        
        var result = ""
        webView.evaluateJavascript(js) { value ->
            result = value?.removeSurrounding("\"") ?: ""
        }
        
        // Wait for result
        var attempts = 0
        while (result.isEmpty() && attempts < 50) {
            kotlinx.coroutines.delay(100)
            attempts++
        }
        
        result
    }
    
    private fun extractAndSaveResources(html: String, pageDir: File, baseUrl: String): Map<String, String> {
        val resources = mutableMapOf<String, String>()
        val resourceDir = File(pageDir, "resources").apply { mkdirs() }
        
        // Extract image URLs
        val imgRegex = "<img[^>]+src=\"([^\"]+)\"".toRegex()
        imgRegex.findAll(html).forEach { match ->
            val originalUrl = match.groupValues[1]
            val absoluteUrl = resolveUrl(originalUrl, baseUrl)
            
            if (!resources.containsKey(absoluteUrl)) {
                val fileName = "img_${resources.size}.bin"
                val file = File(resourceDir, fileName)
                
                try {
                    downloadResource(absoluteUrl, file)
                    resources[absoluteUrl] = "resources/$fileName"
                } catch (e: Exception) {
                    // Skip failed downloads
                }
            }
        }
        
        // Extract CSS URLs
        val cssRegex = "<link[^>]+rel=\"stylesheet\"[^>]+href=\"([^\"]+)\"".toRegex()
        cssRegex.findAll(html).forEach { match ->
            val originalUrl = match.groupValues[1]
            val absoluteUrl = resolveUrl(originalUrl, baseUrl)
            
            if (!resources.containsKey(absoluteUrl)) {
                val fileName = "style_${resources.size}.css"
                val file = File(resourceDir, fileName)
                
                try {
                    downloadResource(absoluteUrl, file)
                    resources[absoluteUrl] = "resources/$fileName"
                } catch (e: Exception) {
                    // Skip failed downloads
                }
            }
        }
        
        // Extract JS URLs
        val jsRegex = "<script[^>]+src=\"([^\"]+)\"".toRegex()
        jsRegex.findAll(html).forEach { match ->
            val originalUrl = match.groupValues[1]
            val absoluteUrl = resolveUrl(originalUrl, baseUrl)
            
            if (!resources.containsKey(absoluteUrl)) {
                val fileName = "script_${resources.size}.js"
                val file = File(resourceDir, fileName)
                
                try {
                    downloadResource(absoluteUrl, file)
                    resources[absoluteUrl] = "resources/$fileName"
                } catch (e: Exception) {
                    // Skip failed downloads
                }
            }
        }
        
        return resources
    }
    
    private fun downloadResource(url: String, file: File) {
        URL(url).openStream().use { input ->
            file.outputStream().use { output ->
                input.copyTo(output)
            }
        }
    }
    
    private fun modifyHtmlForOffline(html: String, resources: Map<String, String>): String {
        var modified = html
        
        // Replace resource URLs with local paths
        resources.forEach { (originalUrl, localPath) ->
            modified = modified.replace("\"$originalUrl\"", "\"$localPath\"")
            modified = modified.replace("'$originalUrl'", "'$localPath'")
        }
        
        // Add base tag
        modified = modified.replace(
            "<head>",
            """<head>
            <base href="./">
            <meta name="offline-page" content="true">
            <style>
                .offline-banner {
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    background: #6366f1;
                    color: white;
                    padding: 8px 16px;
                    font-family: sans-serif;
                    font-size: 12px;
                    z-index: 999999;
                    text-align: center;
                }
            </style>
            """
        )
        
        // Add offline banner
        modified = modified.replace(
            "<body>",
            """<body>
            <div class="offline-banner">Offline Version - Saved Page</div>
            <div style="height: 32px;"></div>
            """
        )
        
        return modified
    }
    
    private fun resolveUrl(url: String, baseUrl: String): String {
        return when {
            url.startsWith("http://") || url.startsWith("https://") -> url
            url.startsWith("//") -> "https:$url"
            url.startsWith("/") -> {
                val base = URL(baseUrl)
                "${base.protocol}://${base.host}$url"
            }
            else -> {
                val base = URL(baseUrl)
                val path = base.path.substringBeforeLast('/') + "/"
                "${base.protocol}://${base.host}$path$url"
            }
        }
    }
    
    private fun saveCompressed(content: String, file: File) {
        GZIPOutputStream(file.outputStream()).bufferedWriter().use {
            it.write(content)
        }
    }
    
    private fun loadCompressed(file: File): String {
        return GZIPInputStream(file.inputStream()).bufferedReader().use {
            it.readText()
        }
    }
    
    private fun updateIndex(page: OfflinePage) {
        val index = getIndex().toMutableList()
        
        // Remove existing entry for same URL
        index.removeAll { it.url == page.url }
        
        // Add new entry at beginning
        index.add(0, page)
        
        // Save index
        saveIndex(index)
    }
    
    private fun saveIndex(pages: List<OfflinePage>) {
        val jsonArray = JSONArray()
        pages.forEach { page ->
            jsonArray.put(JSONObject().apply {
                put("id", page.id)
                put("url", page.url)
                put("title", page.title)
                put("timestamp", page.timestamp)
                put("filePath", page.filePath)
                put("size", page.size)
                put("favicon", page.favicon)
                put("isCompressed", page.isCompressed)
            })
        }
        indexFile.writeText(jsonArray.toString())
    }
    
    fun getIndex(): List<OfflinePage> {
        if (!indexFile.exists()) return emptyList()
        
        return try {
            val jsonArray = JSONArray(indexFile.readText())
            List(jsonArray.length()) { i ->
                val obj = jsonArray.getJSONObject(i)
                OfflinePage(
                    id = obj.getString("id"),
                    url = obj.getString("url"),
                    title = obj.getString("title"),
                    timestamp = obj.getLong("timestamp"),
                    filePath = obj.getString("filePath"),
                    size = obj.getLong("size"),
                    favicon = obj.optString("favicon", null),
                    isCompressed = obj.optBoolean("isCompressed", true)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    fun getOfflinePage(url: String): OfflinePage? {
        return getIndex().find { it.url == url }
    }
    
    fun loadOfflinePage(webView: WebView, page: OfflinePage) {
        val htmlFile = File(page.filePath, "index.html.gz")
        if (htmlFile.exists()) {
            val html = loadCompressed(htmlFile)
            webView.loadDataWithBaseURL(
                "file://${page.filePath}/",
                html,
                "text/html",
                "UTF-8",
                page.url
            )
        }
    }
    
    fun deletePage(pageId: String): Boolean {
        val pageDir = File(offlineDir, pageId)
        return if (pageDir.exists()) {
            pageDir.deleteRecursively()
            
            // Update index
            val index = getIndex().filter { it.id != pageId }
            saveIndex(index)
            
            true
        } else {
            false
        }
    }
    
    fun getTotalSize(): Long {
        return getIndex().sumOf { it.size }
    }
    
    fun clearAll(): Boolean {
        return try {
            offlineDir.listFiles()?.forEach { it.deleteRecursively() }
            saveIndex(emptyList())
            true
        } catch (e: Exception) {
            false
        }
    }
    
    private fun generatePageId(url: String): String {
        val digest = MessageDigest.getInstance("MD5")
        val hash = digest.digest("$url${System.currentTimeMillis()}".toByteArray())
        return hash.joinToString("") { "%02x".format(it) }.substring(0, 16)
    }
}