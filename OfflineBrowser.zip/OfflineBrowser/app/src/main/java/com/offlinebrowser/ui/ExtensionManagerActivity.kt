package com.offlinebrowser.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.offlinebrowser.R
import com.offlinebrowser.extension.ExtensionManager
import java.io.File

class ExtensionManagerActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyView: LinearLayout
    private lateinit var extensionManager: ExtensionManager
    private lateinit var adapter: ExtensionsAdapter
    
    private val PICK_EXTENSION_REQUEST = 1
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_extension_manager)
        
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.extensions)
        
        extensionManager = ExtensionManager(this)
        
        initViews()
        loadExtensions()
    }
    
    private fun initViews() {
        recyclerView = findViewById(R.id.recyclerView)
        emptyView = findViewById(R.id.emptyView)
        
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = ExtensionsAdapter(
            onToggleClick = { ext, enabled ->
                extensionManager.toggleExtension(ext.id, enabled)
            },
            onUninstallClick = { ext ->
                confirmUninstall(ext)
            }
        )
        recyclerView.adapter = adapter
        
        findViewById<Button>(R.id.installBtn).setOnClickListener {
            pickExtension()
        }
    }
    
    private fun loadExtensions() {
        val extensions = extensionManager.getInstalledExtensions()
        adapter.submitList(extensions)
        
        if (extensions.isEmpty()) {
            recyclerView.visibility = View.GONE
            emptyView.visibility = View.VISIBLE
        } else {
            recyclerView.visibility = View.VISIBLE
            emptyView.visibility = View.GONE
        }
        
        supportActionBar?.subtitle = "${extensions.size} installed"
    }
    
    private fun pickExtension() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/json"))
        }
        startActivityForResult(intent, PICK_EXTENSION_REQUEST)
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        if (requestCode == PICK_EXTENSION_REQUEST && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                installExtension(uri)
            }
        }
    }
    
    private fun installExtension(uri: Uri) {
        // In a real implementation, this would extract and install the extension
        Toast.makeText(this, "Extension installation would proceed from: $uri", Toast.LENGTH_LONG).show()
        
        // For demo purposes, show info about extension support
        AlertDialog.Builder(this)
            .setTitle("Extension Support")
            .setMessage("This browser supports Chrome and Firefox extensions. " +
                "To install:\n\n" +
                "1. Download extension files (.zip or extracted folder)\n" +
                "2. Place in: Android/data/com.offlinebrowser/files/extensions/\n" +
                "3. Restart the browser")
            .setPositiveButton("OK", null)
            .show()
    }
    
    private fun confirmUninstall(ext: ExtensionManager.Extension) {
        AlertDialog.Builder(this)
            .setTitle("Uninstall Extension")
            .setMessage("Are you sure you want to uninstall \"${ext.name}\"?")
            .setPositiveButton("Uninstall") { _, _ ->
                uninstallExtension(ext)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun uninstallExtension(ext: ExtensionManager.Extension) {
        val success = extensionManager.uninstallExtension(ext.id)
        if (success) {
            Toast.makeText(this, "Extension uninstalled", Toast.LENGTH_SHORT).show()
            loadExtensions()
        } else {
            Toast.makeText(this, "Failed to uninstall", Toast.LENGTH_SHORT).show()
        }
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    
    override fun onResume() {
        super.onResume()
        loadExtensions()
    }
    
    // Adapter
    class ExtensionsAdapter(
        private val onToggleClick: (ExtensionManager.Extension, Boolean) -> Unit,
        private val onUninstallClick: (ExtensionManager.Extension) -> Unit
    ) : RecyclerView.Adapter<ExtensionsAdapter.ViewHolder>() {
        
        private var extensions = listOf<ExtensionManager.Extension>()
        
        fun submitList(newExtensions: List<ExtensionManager.Extension>) {
            extensions = newExtensions
            notifyDataSetChanged()
        }
        
        override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): ViewHolder {
            val view = android.view.LayoutInflater.from(parent.context)
                .inflate(R.layout.item_extension, parent, false)
            return ViewHolder(view)
        }
        
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            holder.bind(extensions[position])
        }
        
        override fun getItemCount() = extensions.size
        
        inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val nameView: TextView = itemView.findViewById(R.id.extName)
            private val versionView: TextView = itemView.findViewById(R.id.extVersion)
            private val descView: TextView = itemView.findViewById(R.id.extDescription)
            private val authorView: TextView = itemView.findViewById(R.id.extAuthor)
            private val toggle: Switch = itemView.findViewById(R.id.extToggle)
            private val uninstallBtn: ImageButton = itemView.findViewById(R.id.uninstallBtn)
            
            fun bind(ext: ExtensionManager.Extension) {
                nameView.text = ext.name
                versionView.text = "v${ext.version}"
                descView.text = ext.description
                authorView.text = "by ${ext.author}"
                toggle.isChecked = ext.isEnabled
                
                toggle.setOnCheckedChangeListener { _, isChecked ->
                    onToggleClick(ext, isChecked)
                }
                
                uninstallBtn.setOnClickListener {
                    onUninstallClick(ext)
                }
            }
        }
    }
}