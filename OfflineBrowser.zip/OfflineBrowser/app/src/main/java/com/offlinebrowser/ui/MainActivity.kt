package com.offlinebrowser.ui

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.offlinebrowser.R
import com.offlinebrowser.extension.ExtensionManager
import com.offlinebrowser.offline.OfflinePageManager
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var urlInput: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var saveOfflineFab: FloatingActionButton
    
    private lateinit var extensionManager: ExtensionManager
    private lateinit var offlineManager: OfflinePageManager
    
    private var currentUrl: String = ""
    private var currentTitle: String = ""
    
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        // Initialize managers
        extensionManager = ExtensionManager(this)
        offlineManager = OfflinePageManager(this)
        
        // Initialize views
        initViews()
        setupWebView()
        setupListeners()
        
        // Handle intent
        handleIntent(intent)
    }
    
    private fun initViews() {
        webView = findViewById(R.id.webView)
        urlInput = findViewById(R.id.urlInput)
        progressBar = findViewById(R.id.progressBar)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        bottomNav = findViewById(R.id.bottomNav)
        saveOfflineFab = findViewById(R.id.saveOfflineFab)
    }
    
    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            loadWithOverviewMode = true
            useWideViewPort = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            allowFileAccess = true
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
        }
        
        webView.webViewClient = BrowserWebViewClient()
        webView.webChromeClient = BrowserWebChromeClient()
        
        // Enable extension support
        extensionManager.injectExtensions(webView)
        
        // Set download listener
        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
            handleDownload(url, userAgent, contentDisposition, mimeType)
        }
    }
    
    private fun setupListeners() {
        // URL input
        urlInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO || 
                (event?.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_ENTER)) {
                loadUrl(urlInput.text.toString())
                true
            } else {
                false
            }
        }
        
        // Swipe refresh
        swipeRefresh.setOnRefreshListener {
            webView.reload()
        }
        
        // Bottom navigation
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_back -> {
                    if (webView.canGoBack()) webView.goBack()
                    true
                }
                R.id.nav_forward -> {
                    if (webView.canGoForward()) webView.goForward()
                    true
                }
                R.id.nav_home -> {
                    loadUrl("https://www.google.com")
                    true
                }
                R.id.nav_tabs -> {
                    showTabsDialog()
                    true
                }
                R.id.nav_menu -> {
                    showMainMenu()
                    true
                }
                else -> false
            }
        }
        
        // Save offline FAB
        saveOfflineFab.setOnClickListener {
            saveCurrentPageOffline()
        }
    }
    
    private fun loadUrl(url: String) {
        val formattedUrl = when {
            url.startsWith("http://") || url.startsWith("https://") -> url
            url.contains(".") -> "https://$url"
            else -> "https://www.google.com/search?q=$url"
        }
        
        webView.loadUrl(formattedUrl)
        urlInput.setText(formattedUrl)
        urlInput.clearFocus()
    }
    
    private fun handleIntent(intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_VIEW -> {
                val url = intent.dataString
                if (url != null) {
                    loadUrl(url)
                } else {
                    loadUrl("https://www.google.com")
                }
            }
            Intent.ACTION_SEND -> {
                val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
                if (sharedText != null) {
                    if (sharedText.startsWith("http")) {
                        loadUrl(sharedText)
                    } else {
                        loadUrl("https://www.google.com/search?q=$sharedText")
                    }
                }
            }
            else -> loadUrl("https://www.google.com")
        }
    }
    
    private fun saveCurrentPageOffline() {
        if (currentUrl.isBlank() || currentUrl == "about:blank") {
            Toast.makeText(this, "No page to save", Toast.LENGTH_SHORT).show()
            return
        }
        
        CoroutineScope(Dispatchers.Main).launch {
            saveOfflineFab.isEnabled = false
            saveOfflineFab.setImageResource(R.drawable.ic_downloading)
            
            val success = withContext(Dispatchers.IO) {
                offlineManager.savePage(webView, currentUrl, currentTitle)
            }
            
            saveOfflineFab.isEnabled = true
            saveOfflineFab.setImageResource(R.drawable.ic_save)
            
            if (success) {
                Toast.makeText(this@MainActivity, "Page saved for offline!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this@MainActivity, "Failed to save page", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun handleDownload(url: String, userAgent: String, contentDisposition: String, mimeType: String) {
        val request = DownloadManager.Request(Uri.parse(url))
            .setMimeType(mimeType)
            .addRequestHeader("User-Agent", userAgent)
            .setDescription("Downloading...")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, 
                URLUtil.guessFileName(url, contentDisposition, mimeType))
        
        val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        dm.enqueue(request)
        
        Toast.makeText(this, "Download started", Toast.LENGTH_SHORT).show()
    }
    
    private fun showTabsDialog() {
        // Simplified - would show actual tabs in full implementation
        AlertDialog.Builder(this)
            .setTitle("Tabs")
            .setMessage("Current: $currentTitle")
            .setPositiveButton("New Tab") { _, _ ->
                loadUrl("https://www.google.com")
            }
            .setNegativeButton("Close", null)
            .show()
    }
    
    private fun showMainMenu() {
        val options = arrayOf(
            "Offline Pages",
            "Extensions", 
            "Settings",
            "Share",
            "Refresh",
            "Find in Page"
        )
        
        AlertDialog.Builder(this)
            .setTitle("Menu")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> startActivity(Intent(this, OfflinePagesActivity::class.java))
                    1 -> startActivity(Intent(this, ExtensionManagerActivity::class.java))
                    2 -> startActivity(Intent(this, SettingsActivity::class.java))
                    3 -> shareCurrentPage()
                    4 -> webView.reload()
                    5 -> showFindDialog()
                }
            }
            .show()
    }
    
    private fun shareCurrentPage() {
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, currentUrl)
            putExtra(Intent.EXTRA_TITLE, currentTitle)
        }
        startActivity(Intent.createChooser(shareIntent, "Share"))
    }
    
    private fun showFindDialog() {
        val editText = EditText(this)
        editText.hint = "Find in page..."
        
        AlertDialog.Builder(this)
            .setTitle("Find")
            .setView(editText)
            .setPositiveButton("Find") { _, _ ->
                webView.findAllAsync(editText.text.toString())
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (webView.canGoBack()) {
                webView.goBack()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }
    
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }
    
    override fun onResume() {
        super.onResume()
        webView.onResume()
    }
    
    override fun onPause() {
        super.onPause()
        webView.onPause()
    }
    
    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
    
    // WebView Client
    inner class BrowserWebViewClient : WebViewClient() {
        
        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            super.onPageStarted(view, url, favicon)
            progressBar.isVisible = true
            progressBar.progress = 0
            urlInput.setText(url)
            currentUrl = url ?: ""
        }
        
        override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
            progressBar.isVisible = false
            swipeRefresh.isRefreshing = false
            currentTitle = view?.title ?: ""
            
            // Inject extensions after page load
            extensionManager.injectContentScripts(webView, url ?: "")
        }
        
        override fun onLoadResource(view: WebView?, url: String?) {
            super.onLoadResource(view, url)
            // Allow extensions to intercept resources
            extensionManager.interceptResource(url ?: "")
        }
        
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val url = request?.url?.toString() ?: return false
            
            // Handle special schemes
            return when {
                url.startsWith("tel:") -> {
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse(url)))
                    true
                }
                url.startsWith("mailto:") -> {
                    startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse(url)))
                    true
                }
                url.startsWith("intent:") -> {
                    try {
                        startActivity(Intent.parseUri(url, Intent.URI_INTENT_SCHEME))
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "Cannot open app", Toast.LENGTH_SHORT).show()
                    }
                    true
                }
                else -> false
            }
        }
        
        override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
            super.onReceivedError(view, request, error)
            if (request?.isForMainFrame == true) {
                // Check if we have offline version
                val offlinePage = offlineManager.getOfflinePage(currentUrl)
                if (offlinePage != null) {
                    offlineManager.loadOfflinePage(webView, offlinePage)
                    Toast.makeText(this@MainActivity, "Loading offline version", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    // WebChrome Client
    inner class BrowserWebChromeClient : WebChromeClient() {
        
        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            progressBar.progress = newProgress
            if (newProgress == 100) {
                progressBar.isVisible = false
            }
        }
        
        override fun onReceivedTitle(view: WebView?, title: String?) {
            currentTitle = title ?: ""
        }
        
        override fun onShowFileChooser(webView: WebView?, filePathCallback: ValueCallback<Array<Uri>>?, 
            fileChooserParams: FileChooserParams?): Boolean {
            // Handle file picker
            return true
        }
        
        override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
            AlertDialog.Builder(this@MainActivity)
                .setMessage(message)
                .setPositiveButton("OK") { _, _ -> result?.confirm() }
                .setCancelable(false)
                .show()
            return true
        }
        
        override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
            AlertDialog.Builder(this@MainActivity)
                .setMessage(message)
                .setPositiveButton("OK") { _, _ -> result?.confirm() }
                .setNegativeButton("Cancel") { _, _ -> result?.cancel() }
                .setCancelable(false)
                .show()
            return true
        }
    }
}