package com.offlinebrowser.ui

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.offlinebrowser.R
import com.offlinebrowser.offline.OfflinePageManager
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

class OfflinePagesActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyView: LinearLayout
    private lateinit var searchInput: EditText
    private lateinit var offlineManager: OfflinePageManager
    private lateinit var adapter: OfflinePagesAdapter
    
    private var allPages = listOf<OfflinePageManager.OfflinePage>()
    private var filteredPages = listOf<OfflinePageManager.OfflinePage>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_offline_pages)
        
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Offline Pages"
        
        offlineManager = OfflinePageManager(this)
        
        initViews()
        loadPages()
    }
    
    private fun initViews() {
        recyclerView = findViewById(R.id.recyclerView)
        emptyView = findViewById(R.id.emptyView)
        searchInput = findViewById(R.id.searchInput)
        
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = OfflinePagesAdapter(
            onItemClick = { page -> openOfflinePage(page) },
            onDeleteClick = { page -> confirmDelete(page) }
        )
        recyclerView.adapter = adapter
        
        searchInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                filterPages(s?.toString() ?: "")
            }
        })
    }
    
    private fun loadPages() {
        allPages = offlineManager.getIndex()
        filteredPages = allPages
        updateUI()
    }
    
    private fun filterPages(query: String) {
        filteredPages = if (query.isBlank()) {
            allPages
        } else {
            allPages.filter { page ->
                page.title.contains(query, ignoreCase = true) ||
                page.url.contains(query, ignoreCase = true)
            }
        }
        updateUI()
    }
    
    private fun updateUI() {
        adapter.submitList(filteredPages)
        
        if (filteredPages.isEmpty()) {
            recyclerView.visibility = View.GONE
            emptyView.visibility = View.VISIBLE
            
            if (allPages.isEmpty()) {
                emptyView.findViewById<TextView>(R.id.emptyTitle).text = "No Offline Pages"
                emptyView.findViewById<TextView>(R.id.emptySubtitle).text = 
                    "Save pages while browsing to view them offline"
            } else {
                emptyView.findViewById<TextView>(R.id.emptyTitle).text = "No Results"
                emptyView.findViewById<TextView>(R.id.emptySubtitle).text = 
                    "Try a different search term"
            }
        } else {
            recyclerView.visibility = View.VISIBLE
            emptyView.visibility = View.GONE
        }
        
        // Update subtitle with count and size
        val totalSize = offlineManager.getTotalSize()
        val sizeText = formatSize(totalSize)
        supportActionBar?.subtitle = "${filteredPages.size} pages • $sizeText"
    }
    
    private fun openOfflinePage(page: OfflinePageManager.OfflinePage) {
        val intent = Intent(this, OfflineViewerActivity::class.java).apply {
            putExtra("page_id", page.id)
            putExtra("page_url", page.url)
            putExtra("page_title", page.title)
        }
        startActivity(intent)
    }
    
    private fun confirmDelete(page: OfflinePageManager.OfflinePage) {
        AlertDialog.Builder(this)
            .setTitle("Delete Offline Page")
            .setMessage("Are you sure you want to delete \"${page.title}\"?")
            .setPositiveButton("Delete") { _, _ ->
                deletePage(page)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun deletePage(page: OfflinePageManager.OfflinePage) {
        CoroutineScope(Dispatchers.IO).launch {
            val success = offlineManager.deletePage(page.id)
            
            withContext(Dispatchers.Main) {
                if (success) {
                    Toast.makeText(this@OfflinePagesActivity, "Page deleted", Toast.LENGTH_SHORT).show()
                    loadPages()
                } else {
                    Toast.makeText(this@OfflinePagesActivity, "Failed to delete", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    private fun confirmClearAll() {
        AlertDialog.Builder(this)
            .setTitle("Clear All Offline Pages")
            .setMessage("This will delete all saved offline pages. This action cannot be undone.")
            .setPositiveButton("Clear All") { _, _ ->
                clearAllPages()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun clearAllPages() {
        CoroutineScope(Dispatchers.IO).launch {
            val success = offlineManager.clearAll()
            
            withContext(Dispatchers.Main) {
                if (success) {
                    Toast.makeText(this@OfflinePagesActivity, "All pages cleared", Toast.LENGTH_SHORT).show()
                    loadPages()
                } else {
                    Toast.makeText(this@OfflinePagesActivity, "Failed to clear", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    private fun formatSize(bytes: Long): String {
        return when {
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> "${bytes / 1024} KB"
            else -> String.format("%.2f MB", bytes / (1024.0 * 1024.0))
        }
    }
    
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_offline_pages, menu)
        return true
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            R.id.action_clear_all -> {
                confirmClearAll()
                true
            }
            R.id.action_refresh -> {
                loadPages()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    
    override fun onResume() {
        super.onResume()
        loadPages()
    }
    
    // RecyclerView Adapter
    class OfflinePagesAdapter(
        private val onItemClick: (OfflinePageManager.OfflinePage) -> Unit,
        private val onDeleteClick: (OfflinePageManager.OfflinePage) -> Unit
    ) : RecyclerView.Adapter<OfflinePagesAdapter.ViewHolder>() {
        
        private var pages = listOf<OfflinePageManager.OfflinePage>()
        private val dateFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
        
        fun submitList(newPages: List<OfflinePageManager.OfflinePage>) {
            pages = newPages
            notifyDataSetChanged()
        }
        
        override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): ViewHolder {
            val view = android.view.LayoutInflater.from(parent.context)
                .inflate(R.layout.item_offline_page, parent, false)
            return ViewHolder(view)
        }
        
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            holder.bind(pages[position])
        }
        
        override fun getItemCount() = pages.size
        
        inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val titleView: TextView = itemView.findViewById(R.id.pageTitle)
            private val urlView: TextView = itemView.findViewById(R.id.pageUrl)
            private val dateView: TextView = itemView.findViewById(R.id.pageDate)
            private val sizeView: TextView = itemView.findViewById(R.id.pageSize)
            private val deleteBtn: ImageButton = itemView.findViewById(R.id.deleteBtn)
            
            fun bind(page: OfflinePageManager.OfflinePage) {
                titleView.text = page.title
                urlView.text = page.url
                dateView.text = dateFormat.format(Date(page.timestamp))
                sizeView.text = formatSize(page.size)
                
                itemView.setOnClickListener { onItemClick(page) }
                deleteBtn.setOnClickListener { onDeleteClick(page) }
            }
            
            private fun formatSize(bytes: Long): String {
                return when {
                    bytes < 1024 -> "$bytes B"
                    bytes < 1024 * 1024 -> "${bytes / 1024} KB"
                    else -> String.format("%.2f MB", bytes / (1024.0 * 1024.0))
                }
            }
        }
    }
}