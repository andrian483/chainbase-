package com.offlinebrowser.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.offlinebrowser.R
import com.offlinebrowser.offline.OfflinePageManager
import kotlinx.coroutines.*

class OfflineViewerActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var offlineManager: OfflinePageManager
    
    private var pageId: String = ""
    private var pageUrl: String = ""
    private var pageTitle: String = ""
    
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_offline_viewer)
        
        offlineManager = OfflinePageManager(this)
        
        // Get page info from intent
        pageId = intent.getStringExtra("page_id") ?: ""
        pageUrl = intent.getStringExtra("page_url") ?: ""
        pageTitle = intent.getStringExtra("page_title") ?: "Offline Page"
        
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = pageTitle
        supportActionBar?.subtitle = "Offline"
        
        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)
        
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
        }
        
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                progressBar.visibility = View.GONE
            }
        }
        
        loadOfflinePage()
    }
    
    private fun loadOfflinePage() {
        progressBar.visibility = View.VISIBLE
        
        val page = offlineManager.getIndex().find { it.id == pageId }
        if (page != null) {
            offlineManager.loadOfflinePage(webView, page)
        } else {
            Toast.makeText(this, "Page not found", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
    
    private fun sharePage() {
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, pageUrl)
            putExtra(Intent.EXTRA_TITLE, pageTitle)
        }
        startActivity(Intent.createChooser(shareIntent, "Share"))
    }
    
    private fun deletePage() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Delete Offline Page")
            .setMessage("Are you sure you want to delete this page?")
            .setPositiveButton("Delete") { _, _ ->
                CoroutineScope(Dispatchers.IO).launch {
                    offlineManager.deletePage(pageId)
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@OfflineViewerActivity, "Page deleted", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun openOnline() {
        val intent = Intent(this, MainActivity::class.java).apply {
            action = Intent.ACTION_VIEW
            data = android.net.Uri.parse(pageUrl)
        }
        startActivity(intent)
    }
    
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_offline_viewer, menu)
        return true
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            R.id.action_share -> {
                sharePage()
                true
            }
            R.id.action_open_online -> {
                openOnline()
                true
            }
            R.id.action_delete -> {
                deletePage()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    
    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent?): Boolean {
        if (keyCode == android.view.KeyEvent.KEYCODE_BACK) {
            if (webView.canGoBack()) {
                webView.goBack()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }
}