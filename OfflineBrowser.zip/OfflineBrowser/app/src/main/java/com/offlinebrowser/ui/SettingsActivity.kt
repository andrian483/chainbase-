package com.offlinebrowser.ui

import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreferenceCompat
import com.offlinebrowser.R
import com.offlinebrowser.offline.OfflinePageManager

class SettingsActivity : AppCompatActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.settings)
        
        if (savedInstanceState == null) {
            supportFragmentManager
                .beginTransaction()
                .replace(R.id.settings_container, SettingsFragment())
                .commit()
        }
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    
    class SettingsFragment : PreferenceFragmentCompat() {
        
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)
            
            // Clear data preference
            findPreference<androidx.preference.Preference>("clear_data")?.setOnPreferenceClickListener {
                showClearDataDialog()
                true
            }
            
            // About preference
            findPreference<androidx.preference.Preference>("about")?.setOnPreferenceClickListener {
                showAboutDialog()
                true
            }
        }
        
        private fun showClearDataDialog() {
            val items = arrayOf("Clear browsing history", "Clear cookies", "Clear cache", "Clear offline pages")
            val checkedItems = booleanArrayOf(false, false, false, false)
            
            AlertDialog.Builder(requireContext())
                .setTitle("Clear Browsing Data")
                .setMultiChoiceItems(items, checkedItems) { _, which, isChecked ->
                    checkedItems[which] = isChecked
                }
                .setPositiveButton("Clear") { _, _ ->
                    if (checkedItems[3]) { // Clear offline pages
                        val offlineManager = OfflinePageManager(requireContext())
                        offlineManager.clearAll()
                    }
                    Toast.makeText(requireContext(), "Data cleared", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        
        private fun showAboutDialog() {
            AlertDialog.Builder(requireContext())
                .setTitle("Offline Browser")
                .setMessage("Version 1.0.0\n\n" +
                    "A fast, lightweight browser with:\n" +
                    "• Extension support (Chrome/Firefox)\n" +
                    "• Offline page saving\n" +
                    "• Data saver mode\n" +
                    "• Ad blocking\n\n" +
                    "© 2024 Offline Browser Team")
                .setPositiveButton("OK", null)
                .show()
        }
    }
}