#!/bin/bash

# Build script for Offline Browser APK

echo "=========================================="
echo "Offline Browser - APK Build Script"
echo "=========================================="
echo ""

# Check if Android SDK is available
if [ -z "$ANDROID_SDK_ROOT" ] && [ -z "$ANDROID_HOME" ]; then
    echo "WARNING: ANDROID_SDK_ROOT or ANDROID_HOME not set"
    echo "Please set one of these environment variables"
    echo ""
fi

# Clean previous builds
echo "Cleaning previous builds..."
./gradlew clean

# Build debug APK
echo ""
echo "Building Debug APK..."
./gradlew assembleDebug

if [ $? -eq 0 ]; then
    echo ""
    echo "=========================================="
    echo "Debug APK built successfully!"
    echo "=========================================="
    echo "Location: app/build/outputs/apk/debug/app-debug.apk"
    echo ""
    ls -lh app/build/outputs/apk/debug/app-debug.apk
else
    echo ""
    echo "ERROR: Debug build failed!"
    exit 1
fi

# Build release APK (unsigned)
echo ""
echo "Building Release APK (unsigned)..."
./gradlew assembleRelease

if [ $? -eq 0 ]; then
    echo ""
    echo "=========================================="
    echo "Release APK built successfully!"
    echo "=========================================="
    echo "Location: app/build/outputs/apk/release/app-release-unsigned.apk"
    echo ""
    ls -lh app/build/outputs/apk/release/app-release-unsigned.apk
    echo ""
    echo "NOTE: Release APK is unsigned. To sign it:"
    echo "1. Generate keystore:"
    echo "   keytool -genkey -v -keystore offlinebrowser.keystore -alias offlinebrowser -keyalg RSA -keysize 2048 -validity 10000"
    echo ""
    echo "2. Sign APK:"
    echo "   jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore offlinebrowser.keystore app/build/outputs/apk/release/app-release-unsigned.apk offlinebrowser"
    echo ""
    echo "3. Align APK:"
    echo "   zipalign -v 4 app/build/outputs/apk/release/app-release-unsigned.apk OfflineBrowser-v1.0.0.apk"
else
    echo ""
    echo "ERROR: Release build failed!"
    exit 1
fi

echo ""
echo "=========================================="
echo "Build Complete!"
echo "=========================================="