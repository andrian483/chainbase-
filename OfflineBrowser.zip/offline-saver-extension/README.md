# Offline Page Saver

A browser extension that allows you to save web pages for offline viewing. Capture complete pages with all resources and access them anytime, anywhere - even without an internet connection.

## Features

- **Save Pages Offline**: Save any web page with a single click
- **MHTML Format**: Saves complete pages including images, CSS, and scripts in a single file
- **HTML Format**: Alternative HTML saving with embedded resources
- **Offline Viewer**: Built-in viewer to browse saved pages
- **Search & Manage**: Easily search and organize your saved pages
- **Storage Management**: Monitor storage usage and manage saved content
- **Export/Import**: Backup and restore your saved pages
- **Quick Access**: Keyboard shortcuts and context menu integration

## Installation

### Chrome / Edge / Brave

1. Download the extension files
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" in the top right
4. Click "Load unpacked" and select the extension folder
5. The extension icon will appear in your toolbar

### Firefox (with modifications)

This extension uses Manifest V3 and is primarily designed for Chromium-based browsers.

## Usage

### Saving a Page

1. Navigate to any web page you want to save
2. Click the **Offline Page Saver** icon in your toolbar
3. Click "Save Page Offline" button
4. The page will be saved with all its resources

### Viewing Saved Pages

1. Click the extension icon
2. Go to the "Saved Pages" tab
3. Click on any saved page to view it offline
4. Or use the view button (eye icon) on any item

### Managing Saved Pages

- **Search**: Use the search box to find specific pages
- **Delete**: Click the trash icon to remove a saved page
- **Download**: Download saved pages as MHTML or HTML files
- **Clear All**: Remove all saved pages at once

### Settings

- **Save as MHTML**: Toggle between MHTML and HTML formats
- **Auto-save**: Automatically save pages when bookmarking
- **Storage**: Monitor and manage storage usage

## Keyboard Shortcuts

- **Alt+S** (Windows/Linux) or **Option+S** (Mac): Open extension popup

## Context Menu

Right-click on any page and select "Save Page for Offline" to quickly save.

## Storage Information

The extension uses Chrome's local storage with a default quota of 5MB. You can:
- Monitor usage in the Settings tab
- Export pages to free up space
- Import pages from backup files

## File Formats

### MHTML (recommended)
- Single file containing all resources
- Preserves page layout exactly
- Larger file size
- Best for important pages

### HTML
- Smaller file size
- Embedded images as data URLs
- May not capture all dynamic content
- Good for text-heavy pages

## Privacy & Security

- All data is stored locally on your device
- No data is sent to external servers
- Saved pages are accessible only through the extension
- Scripts are removed from saved HTML for security

## Troubleshooting

### Page won't save
- Check if the page is a browser internal page (chrome://, about:)
- Some pages with strict CSP may not save properly
- Try refreshing the page before saving

### Storage full
- Export and delete old pages
- Clear all pages from Settings
- Use download feature to save externally

### Viewer not working
- Make sure the page was saved completely
- Try downloading and opening in browser
- Check console for error messages

## Technical Details

- **Manifest Version**: 3
- **Permissions**: 
  - `activeTab`: Access current page
  - `downloads`: Save files
  - `storage`: Store saved pages
  - `pageCapture`: Capture MHTML
  - `scripting`: Inject content scripts

## License

MIT License - Free to use and modify.

## Support

For issues and feature requests, please create an issue in the repository.