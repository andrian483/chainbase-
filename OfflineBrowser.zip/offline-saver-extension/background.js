// Background service worker for Offline Page Saver extension

// Initialize extension
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('Offline Page Saver installed');
    
    // Set default settings
    chrome.storage.local.set({
      settings: {
        saveAsMhtml: true,
        autoSave: false
      },
      savedPages: []
    });
    
    // Show welcome notification
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: 'Offline Page Saver Installed',
      message: 'Click the extension icon to save pages for offline viewing.'
    });
  }
});

// Listen for messages from popup or content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'savePage') {
    handleSavePage(request.data)
      .then(result => sendResponse({ success: true, result }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true; // Keep message channel open for async
  }
  
  if (request.action === 'getPage') {
    handleGetPage(request.id)
      .then(result => sendResponse({ success: true, result }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }
  
  if (request.action === 'deletePage') {
    handleDeletePage(request.id)
      .then(() => sendResponse({ success: true }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }
  
  if (request.action === 'getAllPages') {
    handleGetAllPages()
      .then(result => sendResponse({ success: true, result }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }
});

// Handle save page
async function handleSavePage(pageData) {
  const result = await chrome.storage.local.get(['savedPages']);
  const savedPages = result.savedPages || [];
  
  // Check if page already exists
  const existingIndex = savedPages.findIndex(p => p.url === pageData.url);
  if (existingIndex !== -1) {
    // Update existing
    savedPages[existingIndex] = {
      ...savedPages[existingIndex],
      ...pageData,
      updatedAt: Date.now()
    };
  } else {
    // Add new
    savedPages.unshift(pageData);
  }
  
  await chrome.storage.local.set({ savedPages });
  return { saved: true, id: pageData.id };
}

// Handle get page
async function handleGetPage(id) {
  const result = await chrome.storage.local.get(['savedPages']);
  const savedPages = result.savedPages || [];
  const page = savedPages.find(p => p.id === id);
  
  if (!page) {
    throw new Error('Page not found');
  }
  
  return page;
}

// Handle delete page
async function handleDeletePage(id) {
  const result = await chrome.storage.local.get(['savedPages']);
  const savedPages = result.savedPages || [];
  const filtered = savedPages.filter(p => p.id !== id);
  
  await chrome.storage.local.set({ savedPages: filtered });
}

// Handle get all pages
async function handleGetAllPages() {
  const result = await chrome.storage.local.get(['savedPages']);
  return result.savedPages || [];
}

// Context menu for quick save
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'savePageOffline',
    title: 'Save Page for Offline',
    contexts: ['page', 'link']
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'savePageOffline') {
    // Open popup to save
    chrome.action.openPopup();
  }
});

// Keyboard shortcut
chrome.commands.onCommand.addListener((command) => {
  if (command === 'save-page') {
    chrome.action.openPopup();
  }
});

// Handle storage changes
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local' && changes.savedPages) {
    // Update badge with count
    const count = changes.savedPages.newValue?.length || 0;
    chrome.action.setBadgeText({
      text: count > 0 ? count.toString() : ''
    });
    chrome.action.setBadgeBackgroundColor({
      color: '#6366f1'
    });
  }
});

// Initialize badge on startup
chrome.storage.local.get(['savedPages']).then(result => {
  const count = result.savedPages?.length || 0;
  chrome.action.setBadgeText({
    text: count > 0 ? count.toString() : ''
  });
  chrome.action.setBadgeBackgroundColor({
    color: '#6366f1'
  });
});