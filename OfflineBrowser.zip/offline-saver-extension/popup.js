// Popup script for Offline Page Saver extension

document.addEventListener('DOMContentLoaded', async () => {
  // DOM Elements
  const pageTitle = document.getElementById('pageTitle');
  const pageUrl = document.getElementById('pageUrl');
  const savePageBtn = document.getElementById('savePageBtn');
  const savedList = document.getElementById('savedList');
  const savedCount = document.getElementById('savedCount');
  const searchInput = document.getElementById('searchInput');
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');
  const notification = document.getElementById('notification');
  const notificationText = document.getElementById('notificationText');
  const clearAllBtn = document.getElementById('clearAllBtn');
  const exportBtn = document.getElementById('exportBtn');
  const importBtn = document.getElementById('importBtn');
  const storageUsed = document.getElementById('storageUsed');
  const storageText = document.getElementById('storageText');
  const saveAsMhtml = document.getElementById('saveAsMhtml');
  const autoSave = document.getElementById('autoSave');

  // State
  let currentTab = null;
  let savedPages = [];

  // Initialize
  await initialize();

  async function initialize() {
    // Get current tab info
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    currentTab = tabs[0];
    
    if (currentTab) {
      pageTitle.textContent = currentTab.title || 'Untitled Page';
      pageUrl.textContent = currentTab.url || '';
    }

    // Load saved pages
    await loadSavedPages();
    
    // Load settings
    await loadSettings();
    
    // Update storage info
    await updateStorageInfo();
  }

  // Load saved pages from storage
  async function loadSavedPages() {
    try {
      const result = await chrome.storage.local.get(['savedPages']);
      savedPages = result.savedPages || [];
      renderSavedPages();
      updateSavedCount();
    } catch (error) {
      console.error('Error loading saved pages:', error);
      showNotification('Error loading saved pages', 'error');
    }
  }

  // Load settings
  async function loadSettings() {
    try {
      const result = await chrome.storage.local.get(['settings']);
      const settings = result.settings || {};
      saveAsMhtml.checked = settings.saveAsMhtml !== false;
      autoSave.checked = settings.autoSave || false;
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  }

  // Save settings
  async function saveSettings() {
    try {
      const settings = {
        saveAsMhtml: saveAsMhtml.checked,
        autoSave: autoSave.checked
      };
      await chrome.storage.local.set({ settings });
    } catch (error) {
      console.error('Error saving settings:', error);
    }
  }

  // Render saved pages list
  function renderSavedPages(filter = '') {
    if (savedPages.length === 0) {
      savedList.innerHTML = `
        <div class="empty-state">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M14 2H6C5.46957 2 4.96086 2.21071 4.58579 2.58579C4.21071 2.96086 4 3.46957 4 4V20C4 20.5304 4.21071 21.0391 4.58579 21.4142C4.96086 21.7893 5.46957 22 6 22H18C18.5304 22 19.0391 21.7893 19.4142 21.4142C19.7893 21.0391 20 20.5304 20 20V8L14 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M14 2V8H20" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M12 18V12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M9 15L12 12L15 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <p>No saved pages yet</p>
          <span>Save your first page to access it offline</span>
        </div>
      `;
      return;
    }

    const filtered = savedPages.filter(page => 
      page.title.toLowerCase().includes(filter.toLowerCase()) ||
      page.url.toLowerCase().includes(filter.toLowerCase())
    );

    if (filtered.length === 0) {
      savedList.innerHTML = `
        <div class="empty-state">
          <p>No results found</p>
          <span>Try a different search term</span>
        </div>
      `;
      return;
    }

    savedList.innerHTML = filtered.map(page => `
      <div class="saved-item" data-id="${page.id}">
        <div class="favicon">
          ${page.favicon ? `<img src="${page.favicon}" alt="">` : `
            <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M14 2H6C5.46957 2 4.96086 2.21071 4.58579 2.58579C4.21071 2.96086 4 3.46957 4 4V20C4 20.5304 4.21071 21.0391 4.58579 21.4142C4.96086 21.7893 5.46957 22 6 22H18C18.5304 22 19.0391 21.7893 19.4142 21.4142C19.7893 21.0391 20 20.5304 20 20V8L14 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M14 2V8H20" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          `}
        </div>
        <div class="item-info">
          <div class="item-title">${escapeHtml(page.title)}</div>
          <div class="item-url">${escapeHtml(new URL(page.url).hostname)}</div>
        </div>
        <div class="item-date">${formatDate(page.savedAt)}</div>
        <div class="item-actions">
          <button class="btn btn-icon view-btn" title="View Offline" data-id="${page.id}">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M1 12S5 4 12 4S23 12 23 12S19 20 12 20S1 12 1 12Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </button>
          <button class="btn btn-icon delete-btn" title="Delete" data-id="${page.id}">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M3 6H5H21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M19 6V20C19 20.5304 18.7893 21.0391 18.4142 21.4142C18.0391 21.7893 17.5304 22 17 22H7C6.46957 22 5.96086 21.7893 5.58579 21.4142C5.21071 21.0391 5 20.5304 5 20V6M8 6V4C8 3.46957 8.21071 2.96086 8.58579 2.58579C8.96086 2.21071 9.46957 2 10 2H14C14.5304 2 15.0391 2.21071 15.4142 2.58579C15.7893 2.96086 16 3.46957 16 4V6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </button>
        </div>
      </div>
    `).join('');

    // Add event listeners to items
    document.querySelectorAll('.saved-item').forEach(item => {
      item.addEventListener('click', (e) => {
        if (!e.target.closest('.item-actions')) {
          const id = item.dataset.id;
          viewOffline(id);
        }
      });
    });

    document.querySelectorAll('.view-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        viewOffline(btn.dataset.id);
      });
    });

    document.querySelectorAll('.delete-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        deletePage(btn.dataset.id);
      });
    });
  }

  // Save current page
  async function saveCurrentPage() {
    if (!currentTab) {
      showNotification('No active tab found', 'error');
      return;
    }

    if (currentTab.url.startsWith('chrome://') || currentTab.url.startsWith('edge://') || currentTab.url.startsWith('about:')) {
      showNotification('Cannot save browser pages', 'error');
      return;
    }

    savePageBtn.disabled = true;
    savePageBtn.innerHTML = '<span class="loading"></span> Saving...';

    try {
      const useMhtml = saveAsMhtml.checked;
      
      if (useMhtml) {
        // Save as MHTML using pageCapture API
        const mhtmlData = await chrome.pageCapture.saveAsMHTML({ tabId: currentTab.id });
        
        // Convert blob to base64
        const reader = new FileReader();
        const base64Promise = new Promise((resolve) => {
          reader.onloadend = () => resolve(reader.result);
          reader.readAsDataURL(mhtmlData);
        });
        const base64Data = await base64Promise;

        const pageData = {
          id: Date.now().toString(),
          title: currentTab.title,
          url: currentTab.url,
          favicon: currentTab.favIconUrl,
          savedAt: Date.now(),
          format: 'mhtml',
          data: base64Data,
          size: base64Data.length
        };

        savedPages.unshift(pageData);
        await chrome.storage.local.set({ savedPages });
        
        showNotification('Page saved successfully!', 'success');
      } else {
        // Save as HTML with resources
        const results = await chrome.scripting.executeScript({
          target: { tabId: currentTab.id },
          func: capturePageContent
        });

        const pageContent = results[0].result;
        
        const pageData = {
          id: Date.now().toString(),
          title: currentTab.title,
          url: currentTab.url,
          favicon: currentTab.favIconUrl,
          savedAt: Date.now(),
          format: 'html',
          html: pageContent.html,
          resources: pageContent.resources,
          size: JSON.stringify(pageContent).length
        };

        savedPages.unshift(pageData);
        await chrome.storage.local.set({ savedPages });
        
        showNotification('Page saved successfully!', 'success');
      }

      await loadSavedPages();
      await updateStorageInfo();
    } catch (error) {
      console.error('Error saving page:', error);
      showNotification('Error saving page: ' + error.message, 'error');
    } finally {
      savePageBtn.disabled = false;
      savePageBtn.innerHTML = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M19 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H16L21 8V19C21 19.5304 20.7893 20.0391 20.4142 20.4142C20.0391 20.7893 19.5304 21 19 21Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M17 21V13H7V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M7 3V8H15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        Save Page Offline
      `;
    }
  }

  // Capture page content for HTML format
  function capturePageContent() {
    const resources = [];
    
    // Get all images
    document.querySelectorAll('img').forEach(img => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth || 100;
        canvas.height = img.naturalHeight || 100;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0);
        const dataUrl = canvas.toDataURL('image/png');
        resources.push({
          type: 'image',
          originalSrc: img.src,
          dataUrl: dataUrl
        });
      } catch (e) {
        console.error('Error capturing image:', e);
      }
    });

    // Clone the document
    const clone = document.documentElement.cloneNode(true);
    
    // Remove scripts for security
    clone.querySelectorAll('script').forEach(script => script.remove());
    
    // Update image sources
    clone.querySelectorAll('img').forEach((img, index) => {
      if (resources[index]) {
        img.src = resources[index].dataUrl;
      }
    });

    return {
      html: clone.outerHTML,
      resources: resources
    };
  }

  // View offline page
  async function viewOffline(id) {
    const page = savedPages.find(p => p.id === id);
    if (!page) {
      showNotification('Page not found', 'error');
      return;
    }

    try {
      // Create viewer URL
      const viewerUrl = chrome.runtime.getURL('viewer.html') + '?id=' + id;
      await chrome.tabs.create({ url: viewerUrl });
    } catch (error) {
      console.error('Error opening viewer:', error);
      showNotification('Error opening page', 'error');
    }
  }

  // Delete saved page
  async function deletePage(id) {
    if (!confirm('Are you sure you want to delete this saved page?')) {
      return;
    }

    try {
      savedPages = savedPages.filter(p => p.id !== id);
      await chrome.storage.local.set({ savedPages });
      await loadSavedPages();
      await updateStorageInfo();
      showNotification('Page deleted', 'success');
    } catch (error) {
      console.error('Error deleting page:', error);
      showNotification('Error deleting page', 'error');
    }
  }

  // Clear all saved pages
  async function clearAllPages() {
    if (!confirm('Are you sure you want to delete all saved pages? This cannot be undone.')) {
      return;
    }

    try {
      savedPages = [];
      await chrome.storage.local.set({ savedPages });
      await loadSavedPages();
      await updateStorageInfo();
      showNotification('All pages cleared', 'success');
    } catch (error) {
      console.error('Error clearing pages:', error);
      showNotification('Error clearing pages', 'error');
    }
  }

  // Export saved pages
  async function exportPages() {
    try {
      const data = {
        version: '1.0',
        exportedAt: Date.now(),
        pages: savedPages
      };
      
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      await chrome.downloads.download({
        url: url,
        filename: `offline-saver-backup-${formatDateForFilename(Date.now())}.json`,
        saveAs: true
      });
      
      showNotification('Export started', 'success');
    } catch (error) {
      console.error('Error exporting:', error);
      showNotification('Error exporting pages', 'error');
    }
  }

  // Import saved pages
  async function importPages() {
    try {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.json';
      
      input.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        const text = await file.text();
        const data = JSON.parse(text);
        
        if (data.pages && Array.isArray(data.pages)) {
          // Merge with existing pages, avoiding duplicates
          const existingIds = new Set(savedPages.map(p => p.id));
          const newPages = data.pages.filter(p => !existingIds.has(p.id));
          
          savedPages = [...newPages, ...savedPages];
          await chrome.storage.local.set({ savedPages });
          await loadSavedPages();
          await updateStorageInfo();
          
          showNotification(`Imported ${newPages.length} pages`, 'success');
        } else {
          showNotification('Invalid backup file', 'error');
        }
      };
      
      input.click();
    } catch (error) {
      console.error('Error importing:', error);
      showNotification('Error importing pages', 'error');
    }
  }

  // Update storage info
  async function updateStorageInfo() {
    try {
      const result = await chrome.storage.local.get(['savedPages']);
      const pages = result.savedPages || [];
      
      // Calculate total size
      let totalSize = 0;
      pages.forEach(page => {
        totalSize += page.size || 0;
      });

      // Get storage quota
      const bytesInUse = await chrome.storage.local.getBytesInUse();
      const quota = chrome.storage.local.QUOTA_BYTES || 5242880; // Default 5MB
      
      const usedMB = (bytesInUse / 1024 / 1024).toFixed(2);
      const totalMB = (quota / 1024 / 1024).toFixed(0);
      const percentage = Math.min((bytesInUse / quota) * 100, 100);
      
      storageUsed.style.width = percentage + '%';
      storageText.textContent = `${usedMB} MB of ${totalMB} MB used`;
      
      // Change color if getting full
      if (percentage > 80) {
        storageUsed.style.background = 'var(--danger)';
      } else if (percentage > 60) {
        storageUsed.style.background = 'var(--warning)';
      } else {
        storageUsed.style.background = 'var(--primary)';
      }
    } catch (error) {
      console.error('Error updating storage info:', error);
    }
  }

  // Update saved count badge
  function updateSavedCount() {
    const count = savedPages.length;
    savedCount.textContent = `${count} saved`;
  }

  // Show notification
  function showNotification(message, type = 'info') {
    notificationText.textContent = message;
    notification.className = 'notification show ' + type;
    
    setTimeout(() => {
      notification.classList.remove('show');
    }, 3000);
  }

  // Format date
  function formatDate(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    
    // Less than 24 hours
    if (diff < 86400000) {
      if (diff < 3600000) {
        const mins = Math.floor(diff / 60000);
        return mins < 1 ? 'Just now' : `${mins}m ago`;
      }
      const hours = Math.floor(diff / 3600000);
      return `${hours}h ago`;
    }
    
    // Less than 7 days
    if (diff < 604800000) {
      const days = Math.floor(diff / 86400000);
      return `${days}d ago`;
    }
    
    return date.toLocaleDateString();
  }

  // Format date for filename
  function formatDateForFilename(timestamp) {
    const date = new Date(timestamp);
    return date.toISOString().split('T')[0];
  }

  // Escape HTML
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // Event Listeners
  savePageBtn.addEventListener('click', saveCurrentPage);

  searchInput.addEventListener('input', (e) => {
    renderSavedPages(e.target.value);
  });

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const tab = btn.dataset.tab;
      
      tabBtns.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));
      
      btn.classList.add('active');
      document.getElementById(tab + 'Tab').classList.add('active');
    });
  });

  clearAllBtn.addEventListener('click', clearAllPages);
  exportBtn.addEventListener('click', exportPages);
  importBtn.addEventListener('click', importPages);
  saveAsMhtml.addEventListener('change', saveSettings);
  autoSave.addEventListener('change', saveSettings);
});