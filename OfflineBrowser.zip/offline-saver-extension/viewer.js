// Viewer script for displaying saved pages offline

document.addEventListener('DOMContentLoaded', async () => {
  // DOM Elements
  const pageTitle = document.getElementById('pageTitle');
  const pageUrl = document.getElementById('pageUrl');
  const backBtn = document.getElementById('backBtn');
  const downloadBtn = document.getElementById('downloadBtn');
  const deleteBtn = document.getElementById('deleteBtn');
  const viewerContainer = document.getElementById('viewerContainer');
  const loading = document.getElementById('loading');

  // Get page ID from URL
  const urlParams = new URLSearchParams(window.location.search);
  const pageId = urlParams.get('id');

  if (!pageId) {
    showError('No page ID specified');
    return;
  }

  // Load the saved page
  await loadPage(pageId);

  async function loadPage(id) {
    try {
      // Get page data from storage
      const result = await chrome.storage.local.get(['savedPages']);
      const savedPages = result.savedPages || [];
      const page = savedPages.find(p => p.id === id);

      if (!page) {
        showError('Page not found', 'The saved page may have been deleted.');
        return;
      }

      // Update header
      pageTitle.textContent = page.title;
      pageUrl.textContent = page.url;
      document.title = page.title + ' - Offline Viewer';

      // Render page content
      if (page.format === 'mhtml' && page.data) {
        // Render MHTML content
        renderMHTML(page.data);
      } else if (page.format === 'html' && page.html) {
        // Render HTML content
        renderHTML(page.html, page.resources);
      } else {
        showError('Invalid page format', 'This page cannot be displayed.');
        return;
      }

      // Store page data for download/delete
      window.currentPage = page;

    } catch (error) {
      console.error('Error loading page:', error);
      showError('Error loading page', error.message);
    }
  }

  function renderMHTML(dataUrl) {
    try {
      // Create iframe for MHTML content
      const iframe = document.createElement('iframe');
      iframe.className = 'viewer-frame';
      
      // Extract base64 data
      const base64Data = dataUrl.split(',')[1];
      const mimeType = 'multipart/related; boundary=----WebKitFormBoundary';
      
      // Convert base64 to blob
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: 'message/rfc822' });
      
      // Create object URL
      const url = URL.createObjectURL(blob);
      
      iframe.src = url;
      
      // Replace loading with iframe
      loading.style.display = 'none';
      viewerContainer.innerHTML = '';
      viewerContainer.appendChild(iframe);

      // Store blob URL for cleanup
      window.blobUrl = url;

    } catch (error) {
      console.error('Error rendering MHTML:', error);
      showError('Error rendering page', error.message);
    }
  }

  function renderHTML(html, resources) {
    try {
      // Create iframe
      const iframe = document.createElement('iframe');
      iframe.className = 'viewer-frame';
      iframe.sandbox = 'allow-same-origin allow-scripts';

      // Create blob with HTML content
      const blob = new Blob([html], { type: 'text/html' });
      const url = URL.createObjectURL(blob);

      iframe.src = url;

      // Replace loading with iframe
      loading.style.display = 'none';
      viewerContainer.innerHTML = '';
      viewerContainer.appendChild(iframe);

      // Store blob URL for cleanup
      window.blobUrl = url;

    } catch (error) {
      console.error('Error rendering HTML:', error);
      showError('Error rendering page', error.message);
    }
  }

  function showError(title, message = '') {
    loading.style.display = 'none';
    viewerContainer.innerHTML = `
      <div class="error">
        <svg class="error-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2"/>
          <path d="M12 8V12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          <circle cx="12" cy="16" r="1" fill="currentColor"/>
        </svg>
        <h2>${escapeHtml(title)}</h2>
        ${message ? `<p>${escapeHtml(message)}</p>` : ''}
        <button class="btn btn-secondary" onclick="history.back()">Go Back</button>
      </div>
    `;
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // Event listeners
  backBtn.addEventListener('click', () => {
    history.back();
  });

  downloadBtn.addEventListener('click', async () => {
    if (!window.currentPage) return;

    try {
      const page = window.currentPage;
      let blob;
      let filename;

      if (page.format === 'mhtml' && page.data) {
        const base64Data = page.data.split(',')[1];
        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        blob = new Blob([byteArray], { type: 'message/rfc822' });
        filename = sanitizeFilename(page.title) + '.mhtml';
      } else {
        blob = new Blob([page.html], { type: 'text/html' });
        filename = sanitizeFilename(page.title) + '.html';
      }

      const url = URL.createObjectURL(blob);
      await chrome.downloads.download({
        url: url,
        filename: filename,
        saveAs: true
      });

    } catch (error) {
      console.error('Error downloading:', error);
      alert('Error downloading file: ' + error.message);
    }
  });

  deleteBtn.addEventListener('click', async () => {
    if (!window.currentPage) return;

    if (!confirm('Are you sure you want to delete this saved page?')) {
      return;
    }

    try {
      const result = await chrome.storage.local.get(['savedPages']);
      const savedPages = result.savedPages || [];
      const filtered = savedPages.filter(p => p.id !== window.currentPage.id);
      
      await chrome.storage.local.set({ savedPages: filtered });
      
      // Close viewer or go back
      history.back();

    } catch (error) {
      console.error('Error deleting:', error);
      alert('Error deleting page: ' + error.message);
    }
  });

  function sanitizeFilename(title) {
    return title.replace(/[^a-z0-9]/gi, '_').substring(0, 50);
  }

  // Cleanup blob URL on page unload
  window.addEventListener('beforeunload', () => {
    if (window.blobUrl) {
      URL.revokeObjectURL(window.blobUrl);
    }
  });
});